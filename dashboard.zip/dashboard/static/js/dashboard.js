const API_BASE = '/api/v1';
const REFRESH_MS = 5000;

const STATUS_DOT_CLASS = {
  'Healthy': 'dot-healthy',
  'Logged Out': 'dot-logged-out',
  'CAPTCHA': 'dot-captcha',
  'Frozen': 'dot-frozen',
  'Chrome Closed': 'dot-closed',
  'Offline': 'dot-offline',
  'Unknown': 'dot-unknown',
};

// Statuses that mean "something needs a human to look at this" -- these get
// the blinking row highlight and trigger a toast the moment they first
// appear, so a non-technical person watching the screen doesn't have to
// read small status text to notice a problem.
const BAD_CHROME_STATUSES = new Set(['Logged Out', 'CAPTCHA', 'Frozen', 'Chrome Closed']);

function token() {
  return localStorage.getItem('scope2_token');
}

function authHeaders() {
  return { 'Authorization': `Bearer ${token()}` };
}

async function apiGet(path, params = {}) {
  const url = new URL(API_BASE + path, window.location.origin);
  Object.entries(params).forEach(([k, v]) => { if (v) url.searchParams.set(k, v); });
  const res = await fetch(url, { headers: authHeaders() });
  if (res.status === 401) {
    window.location.href = '/login';
    throw new Error('unauthorized');
  }
  return res.json();
}

function fmtTime(d) {
  return d.toLocaleTimeString();
}

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str ?? '';
  return div.innerHTML;
}

/* ---------------- Summary ---------------- */

function renderSummary(summary) {
  // Performance (Avg CPU / Avg RAM) is deliberately left out of this
  // top-level summary -- it's technical detail that doesn't help someone
  // scanning for "is everything OK", and per-machine CPU/RAM is still shown
  // on each machine's own card for anyone who does want it.
  const groups = [
    {
      label: 'Systems',
      cards: [
        ['Total Systems', summary.total_systems],
        ['Online', summary.systems_online, summary.systems_online > 0 ? 'accent-good' : ''],
        ['Offline', summary.systems_offline, summary.systems_offline > 0 ? 'accent-bad' : ''],
      ],
    },
    {
      label: 'Chrome Instances',
      cards: [
        ['Total', summary.total_chrome_instances],
        ['Healthy', summary.healthy_browsers, 'accent-good'],
        ['Logged Out', summary.logged_out_browsers, summary.logged_out_browsers > 0 ? 'accent-bad' : ''],
        ['CAPTCHA', summary.captcha_count, summary.captcha_count > 0 ? 'accent-warn' : ''],
        ['Frozen', summary.frozen_browsers, summary.frozen_browsers > 0 ? 'accent-warn' : ''],
        ['Closed', summary.closed_browsers, summary.closed_browsers > 0 ? 'accent-bad' : ''],
      ],
    },
  ];

  const el = document.getElementById('summaryCards');
  el.innerHTML = groups.map(group => `
    <div>
      <div class="summary-group-label">${group.label}</div>
      <div class="summary-row">
        ${group.cards.map(([label, value, accent]) => `
          <div class="summary-card ${accent || ''}">
            <div class="value">${value}</div>
            <div class="label">${label}</div>
          </div>
        `).join('')}
      </div>
    </div>
  `).join('');
}

/* ---------------- Machines ---------------- */

function machineBadgeClass(status) {
  if (status === 'Online') return 'badge-online';
  if (status === 'Warning') return 'badge-warning';
  return 'badge-offline';
}

function renderMachines(machines) {
  const el = document.getElementById('machinesGrid');
  if (!machines.length) {
    el.innerHTML = `<p style="color:var(--text-dim)">No machines registered yet — start an agent to see it appear here.</p>`;
    return;
  }
  el.innerHTML = machines.map(m => `
    <div class="machine-card ${m.status === 'Offline' ? 'blink-alert' : ''}">
      <div class="machine-card-head">
        <span class="machine-name">${escapeHtml(m.machine_name)}</span>
        <span class="machine-badge ${machineBadgeClass(m.status)}">${m.status}</span>
      </div>
      <div class="machine-metrics">
        <span>CPU ${m.cpu_percent?.toFixed?.(0) ?? '—'}%</span>
        <span>RAM ${m.ram_percent?.toFixed?.(0) ?? '—'}%</span>
        <span>Disk ${m.disk_percent?.toFixed?.(0) ?? '—'}%</span>
        <span>${escapeHtml(m.ip_address ?? '')}</span>
      </div>
      ${(m.chrome_instances || []).map(c => `
        <div class="chrome-row ${BAD_CHROME_STATUSES.has(c.status) ? 'blink-alert' : ''}">
          <span class="chrome-dot ${STATUS_DOT_CLASS[c.status] || 'dot-unknown'}"></span>
          <span class="chrome-label">Chrome ${c.instance_index}</span>
          <div class="chrome-info">
            <span class="chrome-status">${c.status}</span>
            <span class="chrome-account ${c.prime_account_name ? '' : 'unknown'}">
              ${c.prime_account_name ? '👤 ' + escapeHtml(c.prime_account_name) : 'account not detected'}
            </span>
          </div>
        </div>
      `).join('')}
    </div>
  `).join('');
}

/* ---------------- Alerts / History ---------------- */

function renderAlerts(alerts, targetId, emptyMessage) {
  const el = document.getElementById(targetId);
  if (!alerts.length) {
    el.innerHTML = `<p style="color:var(--text-dim)">${emptyMessage}</p>`;
    return;
  }
  el.innerHTML = alerts.map(a => `
    <div class="alert-row">
      <span>${escapeHtml(a.machine_name)} — ${escapeHtml(a.message)}</span>
      <span class="alert-time">
        ${new Date(a.created_at * 1000).toLocaleString()}
        ${a.resolved ? ' · resolved ' + new Date(a.resolved_at * 1000).toLocaleString() : ''}
      </span>
    </div>
  `).join('');
}

/* ---------------- Accounts ---------------- */

function renderAccounts(data) {
  const el = document.getElementById('accountsPanel');
  const { accounts, total_accounts, total_assigned_instances, unassigned_instances, highest_used_count } = data;

  if (!accounts.length) {
    el.innerHTML = `<p style="color:var(--text-dim)">No Prime accounts detected yet — account names appear once agents pick up the "Hello, &lt;name&gt;" greeting from a signed-in Chrome window.</p>`;
    return;
  }

  const summaryLine = `
    <div class="summary-row">
      <div class="summary-card"><div class="value">${total_accounts}</div><div class="label">Distinct Accounts</div></div>
      <div class="summary-card"><div class="value">${total_assigned_instances}</div><div class="label">Instances w/ Known Account</div></div>
      <div class="summary-card"><div class="value">${unassigned_instances}</div><div class="label">Account Not Yet Detected</div></div>
    </div>
  `;

  const rows = accounts.map(a => `
    <tr>
      <td class="account-name-cell">
        ${escapeHtml(a.account_name)}
        ${a.is_highest_used ? '<span class="usage-tag tag-highest">Most Used</span>' : ''}
        ${a.is_lowest_used ? '<span class="usage-tag tag-lowest">Least Used</span>' : ''}
      </td>
      <td>
        ${a.instance_count} instance${a.instance_count === 1 ? '' : 's'}
        <div class="usage-bar-track">
          <div class="usage-bar-fill" style="width:${highest_used_count ? (a.instance_count / highest_used_count) * 100 : 0}%"></div>
        </div>
      </td>
      <td class="usage-list">
        ${a.usages.map(u => `${escapeHtml(u.machine_name)}#${u.instance_index} (${u.status})`).join(', ')}
      </td>
    </tr>
  `).join('');

  el.innerHTML = `
    ${summaryLine}
    <table class="accounts-table">
      <thead>
        <tr><th>Account</th><th>Usage</th><th>Where it's signed in</th></tr>
      </thead>
      <tbody>${rows}</tbody>
    </table>
  `;
}

/* ---------------- Settings ---------------- */

function renderSettings() {
  const el = document.getElementById('settingsPanel');
  el.innerHTML = `
    <h3>About this dashboard</h3>
    <p>Scope-2 Monitor watches your Amazon scraping fleet and reports status only —
       it never changes anything on your machines.</p>
    <div class="settings-row"><span>Auto-refresh interval</span><span>${REFRESH_MS / 1000}s</span></div>
    <div class="settings-row"><span>Row highlight</span><span>Blinks red while a Chrome instance needs attention</span></div>
    <div class="settings-row"><span>Notifications</span><span>Pop up top-right the moment a new issue appears</span></div>
  `;
}

/* ---------------- Toast notifications on new incidents ---------------- */

// Tracks last-known status per chrome instance / machine so we only toast on
// a *transition into* a bad state, not on every 5s refresh while it stays bad.
let previousChromeStatuses = new Map(); // key: "machine#index" -> status
let previousMachineStatuses = new Map(); // key: machine_name -> status

function showToast(title, timeLabel) {
  const container = document.getElementById('toastContainer');
  const toast = document.createElement('div');
  toast.className = 'toast';
  toast.innerHTML = `
    <div class="toast-title">${escapeHtml(title)}</div>
    <div class="toast-time">${escapeHtml(timeLabel)}</div>
  `;
  container.appendChild(toast);
  setTimeout(() => toast.remove(), 7000);
}

function checkForNewIncidents(machines) {
  const now = new Date().toLocaleTimeString();

  machines.forEach(m => {
    const prevMachineStatus = previousMachineStatuses.get(m.machine_name);
    if (prevMachineStatus !== undefined && prevMachineStatus !== 'Offline' && m.status === 'Offline') {
      showToast(`⚠ ${m.machine_name} went offline`, now);
    }
    previousMachineStatuses.set(m.machine_name, m.status);

    (m.chrome_instances || []).forEach(c => {
      const key = `${m.machine_name}#${c.instance_index}`;
      const prevStatus = previousChromeStatuses.get(key);
      if (prevStatus !== undefined && prevStatus !== c.status && BAD_CHROME_STATUSES.has(c.status)) {
        showToast(`⚠ ${m.machine_name} Chrome #${c.instance_index}: ${c.status}`, now);
      }
      previousChromeStatuses.set(key, c.status);
    });
  });
}

/* ---------------- View switching ---------------- */

let currentView = 'home';

const VIEW_SECTIONS = {
  home: ['machinesGrid'],
  machines: ['machinesGrid'],
  accounts: ['accountsPanel'],
  alerts: ['alertsPanel'],
  history: ['historyPanel'],
  settings: ['settingsPanel'],
};

const ALL_SECTIONS = ['machinesGrid', 'accountsPanel', 'alertsPanel', 'historyPanel', 'settingsPanel'];

function showViewSections() {
  const visible = VIEW_SECTIONS[currentView] || ['machinesGrid'];
  ALL_SECTIONS.forEach(id => {
    document.getElementById(id).hidden = !visible.includes(id);
  });
}

async function refresh() {
  const search = document.getElementById('searchBox').value;
  const status = document.getElementById('statusFilter').value;
  const sortBy = document.getElementById('sortBy').value;

  const [summary, machinesResp] = await Promise.all([
    apiGet('/dashboard/summary'),
    apiGet('/machines', { search, status, sort_by: sortBy }),
  ]);

  renderSummary(summary);
  renderMachines(machinesResp.machines);
  checkForNewIncidents(machinesResp.machines);

  if (currentView === 'alerts') {
    const alertsResp = await apiGet('/alerts', { resolved: 'false' });
    renderAlerts(alertsResp.alerts, 'alertsPanel', 'No active alerts.');
  }

  if (currentView === 'history') {
    const historyResp = await apiGet('/alerts', { resolved: 'true', limit: 100 });
    renderAlerts(historyResp.alerts, 'historyPanel', 'No resolved incidents yet.');
  }

  if (currentView === 'accounts') {
    const accountsResp = await apiGet('/accounts/summary');
    renderAccounts(accountsResp);
  }

  if (currentView === 'settings') {
    renderSettings();
  }

  document.getElementById('lastRefresh').textContent = fmtTime(new Date());
}

function setupNav() {
  document.querySelectorAll('.nav-item').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.nav-item').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      currentView = btn.dataset.view;
      showViewSections();
      refresh();
    });
  });
}

function setupControls() {
  ['searchBox', 'statusFilter', 'sortBy'].forEach(id => {
    document.getElementById(id).addEventListener('input', refresh);
    document.getElementById(id).addEventListener('change', refresh);
  });
  document.getElementById('logoutBtn').addEventListener('click', () => {
    localStorage.removeItem('scope2_token');
    window.location.href = '/login';
  });
}

(function init() {
  if (!token()) {
    window.location.href = '/login';
    return;
  }
  setupNav();
  setupControls();
  showViewSections();
  refresh();
  setInterval(refresh, REFRESH_MS);
})();
